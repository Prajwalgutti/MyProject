package com.community.connected;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class DeletePlacementsActivity extends AppCompatActivity {

    private RecyclerView jobRecyclerView;
    private JobAdapterWithDelete jobAdapterWithDelete;
    private ArrayList<Job> jobsList;
    private ArrayList<String> jobKeys;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_placements);

        jobRecyclerView = findViewById(R.id.job_list_view); // Ensure ID matches RecyclerView in XML
        jobRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        jobsList = new ArrayList<>();
        jobKeys = new ArrayList<>();

        databaseReference = FirebaseDatabase.getInstance().getReference("jobs");

        jobAdapterWithDelete = new JobAdapterWithDelete(this, jobsList, jobKeys);
        jobRecyclerView.setAdapter(jobAdapterWithDelete);

        // Fetch and display jobs
        fetchJobs();
    }

    private void fetchJobs() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                jobsList.clear();
                jobKeys.clear();

                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String key = snapshot.getKey();
                    String title = snapshot.child("title").getValue(String.class);
                    String company = snapshot.child("company").getValue(String.class);
                    String applyLink = snapshot.child("applyLink").getValue(String.class);

                    if (key != null && title != null && company != null && applyLink != null) {
                        jobsList.add(new Job(title, company, applyLink));
                        jobKeys.add(key);
                    }
                }

                if (jobsList.isEmpty()) {
                    Toast.makeText(DeletePlacementsActivity.this, "No jobs available", Toast.LENGTH_SHORT).show();
                }

                // Notify adapter to refresh the RecyclerView
                jobAdapterWithDelete.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(DeletePlacementsActivity.this, "Failed to load jobs", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

