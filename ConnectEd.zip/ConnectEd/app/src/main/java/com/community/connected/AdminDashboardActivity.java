package com.community.connected;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

// Inside your AdminPageActivity.java
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AdminDashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        Button btnHome = findViewById(R.id.btn_home);
        Button btnRequests = findViewById(R.id.btn_requests);

        // Home button click
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the home page
                Intent homeIntent = new Intent(AdminDashboardActivity.this, Homepage.class);
                startActivity(homeIntent);
            }
        });

        // Requests button click
        btnRequests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the requests page
                Intent requestsIntent = new Intent(AdminDashboardActivity.this, Request.class);
                startActivity(requestsIntent);
            }
        });
    }
}
