package com.community.connected;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Request extends AppCompatActivity {

    private LinearLayout requestContainer;
    private LinearLayout facultyRequestContainer;  // New container for faculty requests
    private LinearLayout alumniRequestContainer;

    private DatabaseReference studentDatabaseReference;
    private DatabaseReference facultyDatabaseReference;  // Firebase reference for faculty
    private DatabaseReference alumniDatabaseReference;

    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request);

        requestContainer = findViewById(R.id.requestContainer);
        facultyRequestContainer = findViewById(R.id.facultyRequestContainer);
        alumniRequestContainer=findViewById(R.id.alumniRequestContainer);// Initialize faculty container

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        // Initialize Firebase database references
        studentDatabaseReference = FirebaseDatabase.getInstance().getReference("ApprovedStudents");
        facultyDatabaseReference = FirebaseDatabase.getInstance().getReference("ApprovedFaculty");
        alumniDatabaseReference = FirebaseDatabase.getInstance().getReference("Approvedalumni");


        loadStudentRequests();
        loadFacultyRequests();
        loadAlumniRequests();// Load faculty requests
    }

    private void loadStudentRequests() {
        // Get saved registration data from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("StudentRequests", MODE_PRIVATE);
        String name = preferences.getString("name", "No Name");
        String batch = preferences.getString("batch", "No Batch");
        String usn = preferences.getString("usn", "No USN");
        String email = preferences.getString("email", "No Email");
        String branch = preferences.getString("branch", "No Branch");
        String password = preferences.getString("password", "No password");


        // Create a new request card for students
        View requestCard = getLayoutInflater().inflate(R.layout.request_card, null);

        TextView nameTextView = requestCard.findViewById(R.id.nameTextView);
        TextView batchTextView = requestCard.findViewById(R.id.batchTextView);
        TextView usnTextView = requestCard.findViewById(R.id.usnTextView);
        TextView emailTextView = requestCard.findViewById(R.id.emailTextView);
        TextView branchTextView = requestCard.findViewById(R.id.branchTextView);
        TextView passwordTextView = requestCard.findViewById(R.id.passwordTextView);


        // Set values to the card
        nameTextView.setText(name);
        batchTextView.setText(batch);
        usnTextView.setText(usn);
        emailTextView.setText(email);
        branchTextView.setText(branch);
        passwordTextView.setText(password);


        Button approveButton = requestCard.findViewById(R.id.approveButton);
        Button rejectButton = requestCard.findViewById(R.id.rejectButton);

        approveButton.setOnClickListener(v -> approveRequest(name, batch, usn, email, branch,password, requestCard, "student"));
        rejectButton.setOnClickListener(v -> rejectRequest(requestCard));

        // Add the request card to the student container
        requestContainer.addView(requestCard);
    }

    private void loadFacultyRequests() {
        // Get saved faculty registration data from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("FacultyRequests", MODE_PRIVATE);
        String name = preferences.getString("name", "No Name");
        String department = preferences.getString("department", "No Department");
        String email = preferences.getString("email", "No Email");
        String designation = preferences.getString("designation", "No Designation");
        String qualification = preferences.getString("qualification", "No Qualification");
        String password = preferences.getString("password", "No password");


        // Create a new request card for faculty
        View requestCard = getLayoutInflater().inflate(R.layout.request_cardf, null);

        TextView nameTextView = requestCard.findViewById(R.id.nameTextView);
        TextView departmentTextView = requestCard.findViewById(R.id.departmentTextView);
        TextView emailTextView = requestCard.findViewById(R.id.emailTextView);
        TextView designationTextView = requestCard.findViewById(R.id.designationTextView);
        TextView qualificationTextView = requestCard.findViewById(R.id.qualificationTextView);
        TextView passwordTextView = requestCard.findViewById(R.id.passwordTextView);


        // Set values to the card
        nameTextView.setText(name);
        departmentTextView.setText(department);
        emailTextView.setText(email);
        designationTextView.setText(designation);
        qualificationTextView.setText(qualification);
        passwordTextView.setText(password);


        Button approveButton = requestCard.findViewById(R.id.approveButton);
        Button rejectButton = requestCard.findViewById(R.id.rejectButton);

        approveButton.setOnClickListener(v -> approveRequest(name, department, email, designation, qualification, password,requestCard, "faculty"));
        rejectButton.setOnClickListener(v -> rejectRequest(requestCard));

        // Add the request card to the faculty container
        facultyRequestContainer.addView(requestCard);
    }

    private void loadAlumniRequests() {
        // Get saved alumni registration data from SharedPreferences
        SharedPreferences preferences = getSharedPreferences("AlumniRequests", MODE_PRIVATE);
        String name = preferences.getString("name", "No Name");
        String batch = preferences.getString("batch","No Batch");
        String usn = preferences.getString("usn","No usn");
        String email = preferences.getString("email", "No Email");
        String profession = preferences.getString("profession", "No Profession");
        String branch = preferences.getString("branch", "No Branch");
        String password = preferences.getString("password", "No password");


        // Create a new request card for faculty
        View requestCard = getLayoutInflater().inflate(R.layout.request_carda, null);

        TextView nameTextView = requestCard.findViewById(R.id.nameTextView);
        TextView batchTextView = requestCard.findViewById(R.id.batchTextView);
        TextView usnTextView = requestCard.findViewById(R.id.usnTextView);
        TextView emailTextView = requestCard.findViewById(R.id.emailTextView);
        TextView professionTextView = requestCard.findViewById(R.id.professionTextView);
        TextView branchTextView = requestCard.findViewById(R.id.branchTextView);
        TextView passwordTextView = requestCard.findViewById(R.id.passwordTextView);


        // Set values to the card
        nameTextView.setText(name);
        batchTextView.setText(batch);
        usnTextView.setText(usn);
        emailTextView.setText(email);
        professionTextView.setText(profession);
        branchTextView.setText(branch);
        passwordTextView.setText(password);


        Button approveButton = requestCard.findViewById(R.id.approveButton);
        Button rejectButton = requestCard.findViewById(R.id.rejectButton);

        approveButton.setOnClickListener(v -> approveRequest(name, batch,usn, email, profession, branch, password ,requestCard, "alumni"));
        rejectButton.setOnClickListener(v -> rejectRequest(requestCard));

        // Add the request card to the faculty container
        alumniRequestContainer.addView(requestCard);
    }

    private void approveRequest(String name, String batchOrDepartment, String usnOrEmail, String emailOrDesignation, String branchOrQualification, String password, View requestCard, String type) {
        if (currentUser != null) {
            if (type.equals("student")) {
                Student student = new Student(name, batchOrDepartment, usnOrEmail, emailOrDesignation, branchOrQualification, password);
                studentDatabaseReference.child(usnOrEmail).setValue(student)
                        .addOnSuccessListener(aVoid -> requestContainer.removeView(requestCard))
                        .addOnFailureListener(e -> e.printStackTrace());
            } else if (type.equals("faculty")) {
                // Create a new faculty object
                Faculty faculty = new Faculty(name, batchOrDepartment, usnOrEmail, emailOrDesignation, branchOrQualification,password);

                // Push to Firebase
                facultyDatabaseReference.child(usnOrEmail.replace("@", "at").replace(".", "dot")).setValue(faculty)
                        .addOnSuccessListener(aVoid -> {
                            // Remove the card from the UI
                            facultyRequestContainer.removeView(requestCard);
                        })
                        .addOnFailureListener(e -> {
                            // Handle the error
                            e.printStackTrace();
                        });
            }

        } else {
            Toast.makeText(Request.this, "Please log in to approve requests", Toast.LENGTH_SHORT).show();
        }
    }

    private void approveRequest(String name, String batchOrDepartment, String usnOrEmail, String emailOrDesignation, String branchOrQualification, String password, String profession, View requestCard, String type) {
        if (currentUser != null) {
            if (type.equals("alumni")) {
                // Correctly map the parameters to the attributes of the Alumni class
                Alumni alumni = new Alumni(name, batchOrDepartment, usnOrEmail, emailOrDesignation, profession,branchOrQualification,password);

                alumniDatabaseReference.child(usnOrEmail).setValue(alumni)
                        .addOnSuccessListener(aVoid -> alumniRequestContainer.removeView(requestCard))
                        .addOnFailureListener(e -> e.printStackTrace());
            }
        } else {
            Toast.makeText(Request.this, "Please log in to approve requests", Toast.LENGTH_SHORT).show();
        }
    }

    private void rejectRequest(View requestCard) {
        // Remove the card from the UI
        requestContainer.removeView(requestCard);
        facultyRequestContainer.removeView(requestCard);
        alumniRequestContainer.removeView(requestCard);
    }

    // Define a Student class for Firebase
    public static class Student {
        public String name, batch, usn, email, branch,password;

        public Student() {
            // Default constructor required for Firebase
        }

        public Student(String name, String batch, String usn, String email, String branch,String password) {
            this.name = name;
            this.batch = batch;
            this.usn = usn;
            this.email = email;
            this.branch = branch;
            this.password=password;
        }
    }

    // Define a Faculty class for Firebase

    public static class Faculty {
        public String name, department, email, designation, qualification,password;

        public Faculty() {
            // Default constructor required for Firebase
        }

        public Faculty(String name, String department, String email, String designation, String qualification,String password) {
            this.name = name;
            this.department = department;
            this.email = email;
            this.designation = designation;
            this.qualification = qualification;
            this.password=password;
        }
    }
    public static class Alumni {
        public String name, batch, usn, email, profession, branch ,password;

        public Alumni() {
            // Default constructor required for Firebase
        }

        public Alumni(String name, String batch, String usn,String email, String profession, String branch,String password) {
            this.name = name;
            this.batch = batch;
            this.usn=usn;
            this.email = email;
            this.profession = profession;
            this.branch = branch;
            this.password=password;
        }
    }
}

