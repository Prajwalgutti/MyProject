package com.community.connected;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class AdminSignpage extends AppCompatActivity {

    private TextInputEditText emailInput, passwordInput;
    private Button signInButton;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_signpage);

        // Initialize Firebase
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Bind UI elements
        emailInput = findViewById(R.id.email);
        passwordInput = findViewById(R.id.password);
        signInButton = findViewById(R.id.signIn);

        // Handle Sign-In button click
        signInButton.setOnClickListener(view -> adminLogin());
    }

    private void adminLogin() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Sign in with Firebase Authentication
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // Check if user is in the "admins" Firestore collection
                        db.collection("admins").document(auth.getCurrentUser().getUid())
                                .get()
                                .addOnSuccessListener(documentSnapshot -> {
                                    if (documentSnapshot.exists()) {
                                        // Redirect to Admin Dashboard
                                        Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(this, AdminDashboardActivity.class));
                                        finish();
                                    } else {
                                        Toast.makeText(this, "Access Denied: Not an admin!", Toast.LENGTH_SHORT).show();
                                        auth.signOut();
                                    }
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    } else {
                        Toast.makeText(this, "Login failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
