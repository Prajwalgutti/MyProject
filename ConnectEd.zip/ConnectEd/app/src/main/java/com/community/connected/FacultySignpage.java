package com.community.connected;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FacultySignpage extends AppCompatActivity {

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_signpage);

        databaseReference = FirebaseDatabase.getInstance().getReference("ApprovedFaculty");

        // Initialize register button
        final Button registerButton = findViewById(R.id.fregister);
        final Button loginButton=findViewById(R.id.signIn);
        final EditText emailInput=findViewById(R.id.email);
        final EditText passwordInput=findViewById(R.id.password);

        // Set OnClickListener
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to FacultyRegistrationpage
                Intent intent = new Intent(FacultySignpage.this, FacultyRegistrationpage.class);
                startActivity(intent);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = emailInput.getText().toString().trim();
                final String password = passwordInput.getText().toString().trim();

                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                    Toast.makeText(FacultySignpage.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    // Replace special characters in the email to match the stored format
                    final String semail = email.replace(".", "dot");
                    final String cemail=semail.replace("@","at");

                    databaseReference.child(cemail).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                String storedPassword = snapshot.child("password").getValue(String.class);
                                if (storedPassword != null && storedPassword.equals(password)) {
                                    Toast.makeText(FacultySignpage.this, "Successfully Logged In", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(FacultySignpage.this, Homepage.class));
                                    finish();
                                } else {
                                    Toast.makeText(FacultySignpage.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(FacultySignpage.this, "Email not found", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(FacultySignpage.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}