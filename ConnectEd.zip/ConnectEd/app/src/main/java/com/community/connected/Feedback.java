package com.community.connected;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import androidx.annotation.NonNull;

public class Feedback extends AppCompatActivity {

    private TextView feedbackDisplay;
    private Button submitButton;
    private DatabaseReference feedbackDatabase;
    private EditText feedbackInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        // Initialize Firebase database references
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        feedbackDatabase = database.getReference("feedback");

        // Initialize views
        submitButton = findViewById(R.id.submitB);
        feedbackDisplay = findViewById(R.id.feedbackD);
        feedbackInput = findViewById(R.id.feedbackI);

        // Set listener for the submit button
        submitButton.setOnClickListener(v -> submitFeedback());

        // Display feedback
        displayFeedback();
    }

    private void submitFeedback() {
        String feedback = feedbackInput.getText().toString().trim();

        // Validate input
        if (feedback.isEmpty()) {
            Toast.makeText(this, "Feedback cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a new feedback item and store it in the database
        String feedbackId = feedbackDatabase.push().getKey();
        if (feedbackId != null) {
            feedbackDatabase.child(feedbackId).setValue(feedback)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(Feedback.this, "Feedback submitted successfully", Toast.LENGTH_SHORT).show();
                            feedbackInput.setText(""); // Clear feedback input
                        } else {
                            Toast.makeText(Feedback.this, "Failed to submit feedback", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void displayFeedback() {
        feedbackDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                StringBuilder feedbackText = new StringBuilder();
                for (DataSnapshot feedbackSnapshot : dataSnapshot.getChildren()) {
                    String feedback = feedbackSnapshot.getValue(String.class);
                    if (feedback != null) {
                        feedbackText.append("- ").append(feedback).append("\n");
                    }
                }
                feedbackDisplay.setText(feedbackText.toString());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                feedbackDisplay.setText("Failed to load feedback.");
            }
        });
    }
}
