package com.community.connected;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class ViewGallery extends AppCompatActivity {
    RecyclerView images;
    ImageAdapter adapter;
    List<String> base64Images;
    List<String> descriptions;
    FirebaseFirestore db;
    ImageView addimage;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view_gallery);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        images = findViewById(R.id.images);
        images.setLayoutManager(new LinearLayoutManager(this));
        base64Images = new ArrayList<>();
        descriptions = new ArrayList<>();
        db = FirebaseFirestore.getInstance();
        addimage = findViewById(R.id.addimage);

        // Set up the adapter
        adapter = new ImageAdapter(base64Images, descriptions);
        images.setAdapter(adapter);

        // On-click listener for the "add image" button
        addimage.setOnClickListener(v -> startActivity(new Intent(ViewGallery.this, UploadImage.class)));

        fetchImagesFromFirestore();
    }

    private void fetchImagesFromFirestore() {
        db.collection("images").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (QueryDocumentSnapshot document : task.getResult()) {
                    String base64Image = document.getString("image");
                    String description = document.getString("description");
                    if (base64Image != null && description != null) {
                        base64Images.add(base64Image);
                        descriptions.add(description);
                    }
                }
                adapter.notifyDataSetChanged();
            } else {
                Toast.makeText(this, "Failed to fetch images", Toast.LENGTH_SHORT).show();
            }
        });
    }
}