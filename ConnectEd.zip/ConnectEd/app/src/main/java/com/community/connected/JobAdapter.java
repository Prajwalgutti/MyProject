package com.community.connected;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.community.connected.Job;

import java.util.ArrayList;
import androidx.appcompat.app.AppCompatActivity;
public class JobAdapter extends ArrayAdapter<Job> {

    private Context context;
    private ArrayList<Job> jobs;

    public JobAdapter(Context context, ArrayList<Job> jobs) {
        super(context, 0, jobs);
        this.context = context;
        this.jobs = jobs;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item_job, parent, false);
        }

        // Get current job
        Job currentJob = jobs.get(position);

        // Set job title
        TextView titleView = convertView.findViewById(R.id.job_title);
        titleView.setText(currentJob.getTitle());

        // Set company name
        TextView companyView = convertView.findViewById(R.id.job_company);
        companyView.setText(currentJob.getCompany());

        // Set apply link text
        TextView linkView = convertView.findViewById(R.id.job_apply_link);
        linkView.setText("Apply here");

        // Make the "Apply here" link clickable and open the URL
        linkView.setOnClickListener(v -> {
            String url = currentJob.getApplyLink(); // Get the apply link for the clicked job
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); // Open the apply URL in the browser
            context.startActivity(intent); // Launch the URL
        });

        return convertView;
    }
}
