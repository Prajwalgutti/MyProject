package com.community.connected;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class GalleryView extends AppCompatActivity {
    RecyclerView images;
    SImageAdapter adapter;
    List<String> base64Images = new ArrayList<>();
    List<String> descriptions = new ArrayList<>();
    FirebaseFirestore db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery_view);

        images = findViewById(R.id.images);
        images.setLayoutManager(new LinearLayoutManager(this)); // Ensures vertical scrolling works smoothly

        adapter = new SImageAdapter(base64Images, descriptions);
        images.setAdapter(adapter);

        fetchImagesFromFirestore();
    }

    private void fetchImagesFromFirestore() {
        db = FirebaseFirestore.getInstance();
        db.collection("images")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        base64Images.clear();
                        descriptions.clear();  // Clear previous data

                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String description = document.getString("description");
                            String base64Image = document.getString("image");

                            if (description != null && base64Image != null) {
                                descriptions.add(description);
                                base64Images.add(base64Image);  // Store the Base64 image string
                            }
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(this, "Failed to fetch images", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}