package com.community.connected;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SImageAdapter extends RecyclerView.Adapter<SImageAdapter.ImageViewHolder> {
    private final List<String> base64Images;
    private final List<String> descriptions;

    public SImageAdapter(List<String> base64Images, List<String> descriptions) {
        this.base64Images = base64Images;
        this.descriptions = descriptions;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_gallery, parent, false);
        return new ImageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        String base64Image = base64Images.get(position);
        Bitmap bitmap = decodeBase64ToBitmap(base64Image);
        holder.imageView.setImageBitmap(bitmap);

        if (position < descriptions.size()) {
            holder.desc.setText(descriptions.get(position));
        } else {
            holder.desc.setText("No description available");
        }
    }

    @Override
    public int getItemCount() {
        return Math.max(base64Images.size(), descriptions.size());
    }

    public static class ImageViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView desc;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.image);
            desc = itemView.findViewById(R.id.desc);
        }
    }

    private Bitmap decodeBase64ToBitmap(String base64Image) {
        byte[] decodedBytes = Base64.decode(base64Image, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}