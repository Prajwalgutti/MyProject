package com.community.connected;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddJobActivity extends AppCompatActivity {

    private EditText jobTitleEditText;
    private EditText jobCompanyEditText;
    private EditText jobApplyLinkEditText;
    private Button saveJobButton;

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_job);

        jobTitleEditText = findViewById(R.id.job_title);
        jobCompanyEditText = findViewById(R.id.job_company);
        jobApplyLinkEditText = findViewById(R.id.job_apply_link);
        saveJobButton = findViewById(R.id.save_job_button);

        databaseReference = FirebaseDatabase.getInstance().getReference("jobs");

        saveJobButton.setOnClickListener(v -> {
            String title = jobTitleEditText.getText().toString().trim();
            String company = jobCompanyEditText.getText().toString().trim();
            String applyLink = jobApplyLinkEditText.getText().toString().trim();

            if (!title.isEmpty() && !company.isEmpty() && !applyLink.isEmpty()) {
                String jobId = databaseReference.push().getKey();
                Job newJob = new Job(title, company, applyLink);
                databaseReference.child(jobId).setValue(newJob);
                Toast.makeText(AddJobActivity.this, "Job added successfully!", Toast.LENGTH_SHORT).show();
                finish();  // Close the activity after adding the job
            } else {
                Toast.makeText(AddJobActivity.this, "All fields are required!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

