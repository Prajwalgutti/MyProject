package com.community.connected;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class PlacementsActivity extends AppCompatActivity {
    private static final String TAG = "PlacementsActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placements);

        ListView jobList = findViewById(R.id.job_list);
        ArrayList<Job> jobs = new ArrayList<>();
        JobAdapter adapter = new JobAdapter(this, jobs);
        jobList.setAdapter(adapter);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("jobs");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                jobs.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String title = snapshot.child("title").getValue(String.class);
                    String company = snapshot.child("company").getValue(String.class);
                    String applyLink = snapshot.child("applyLink").getValue(String.class);

                    if (title != null && company != null && applyLink != null) {
                        jobs.add(new Job(title, company, applyLink));
                        Log.d(TAG, "Job fetched: " + title);
                    } else {
                        Log.w(TAG, "Incomplete job data: " + snapshot.toString());
                    }
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e(TAG, "Error fetching data", databaseError.toException());
                Toast.makeText(PlacementsActivity.this, "Failed to load jobs", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
