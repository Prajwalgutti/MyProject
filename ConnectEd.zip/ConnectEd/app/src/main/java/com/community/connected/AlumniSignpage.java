package com.community.connected;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AlumniSignpage extends AppCompatActivity {

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alumni_signpage);

        databaseReference = FirebaseDatabase.getInstance().getReference("Approvedalumni");
        // Initialize register button
        final Button registerButton = findViewById(R.id.aregister);
        final Button loginButton = findViewById(R.id.signIn);
        final EditText usnInput = findViewById(R.id.usn);
        final EditText passwordInput = findViewById(R.id.password);

        // Set OnClickListener
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AlumniRegistrationpage
                Intent intent = new Intent(AlumniSignpage.this, AlumniRegistrationpage.class);
                startActivity(intent);
            }
        });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String usn = usnInput.getText().toString().trim();
                final String password = passwordInput.getText().toString().trim();

                if (TextUtils.isEmpty(usn) || TextUtils.isEmpty(password)) {
                    Toast.makeText(AlumniSignpage.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    databaseReference.child(usn).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                String storedPassword = snapshot.child("profession").getValue(String.class);
                                if (storedPassword != null && storedPassword.equals(password)) {
                                    Toast.makeText(AlumniSignpage.this, "Successfully Logged In", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(AlumniSignpage.this, Homepage.class));
                                    finish();
                                } else {
                                    Toast.makeText(AlumniSignpage.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(AlumniSignpage.this, "USN not found", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(AlumniSignpage.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
