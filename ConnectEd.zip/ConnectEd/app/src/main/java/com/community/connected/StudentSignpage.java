package com.community.connected;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class StudentSignpage extends AppCompatActivity {

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_signpage);

        // Initialize Firebase Database
        databaseReference = FirebaseDatabase.getInstance().getReference("ApprovedStudents");

        // Initialize UI elements
        final Button registerButton = findViewById(R.id.sregister);
        final Button loginButton = findViewById(R.id.signIn);
        final EditText usnInput = findViewById(R.id.usn);
        final EditText passwordInput = findViewById(R.id.password);

        // Register button logic
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StudentSignpage.this, StudentRegistrationpage.class);
                startActivity(intent);
            }
        });

        // Login button logic
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String usn = usnInput.getText().toString().trim();
                final String password = passwordInput.getText().toString().trim();

                if (TextUtils.isEmpty(usn) || TextUtils.isEmpty(password)) {
                    Toast.makeText(StudentSignpage.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    databaseReference.child(usn).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                String storedPassword = snapshot.child("password").getValue(String.class);
                                if (storedPassword != null && storedPassword.equals(password)) {
                                    Toast.makeText(StudentSignpage.this, "Successfully Logged In", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(StudentSignpage.this, Homepagestudent.class));
                                    finish();
                                } else {
                                    Toast.makeText(StudentSignpage.this, "Wrong Password", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(StudentSignpage.this, "USN not found", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Toast.makeText(StudentSignpage.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
