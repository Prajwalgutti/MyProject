package com.community.connected;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class UserSelection extends AppCompatActivity {

    Button student, alumni, faculty, admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_selection);

        // Initializing buttons
        student = findViewById(R.id.student);
        alumni = findViewById(R.id.alumni);
        faculty = findViewById(R.id.faculty);
        admin = findViewById(R.id.admin);

        // Set onClickListeners
        student.setOnClickListener(v -> {
            Intent studentIntent = new Intent(UserSelection.this, StudentSignpage.class);
            startActivity(studentIntent);
        });

        alumni.setOnClickListener(v -> {
            Intent alumniIntent = new Intent(UserSelection.this, AlumniSignpage.class);
            startActivity(alumniIntent);
        });

        faculty.setOnClickListener(v -> {
            Intent facultyIntent = new Intent(UserSelection.this, FacultySignpage.class);
            startActivity(facultyIntent);
        });

        admin.setOnClickListener(v -> {
            Intent adminIntent = new Intent(UserSelection.this, AdminSignpage.class);
            startActivity(adminIntent);
        });
    }
}
