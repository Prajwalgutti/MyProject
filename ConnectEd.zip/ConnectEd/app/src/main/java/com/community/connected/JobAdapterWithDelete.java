package com.community.connected;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;

public class JobAdapterWithDelete extends RecyclerView.Adapter<JobAdapterWithDelete.JobViewHolder> {

    private final Context context;
    private final ArrayList<Job> jobList;
    private final ArrayList<String> jobKeys;
    private final DatabaseReference databaseReference;

    public JobAdapterWithDelete(Context context, ArrayList<Job> jobList, ArrayList<String> jobKeys) {
        this.context = context;
        this.jobList = jobList;
        this.jobKeys = jobKeys;
        this.databaseReference = FirebaseDatabase.getInstance().getReference("jobs");
    }

    @NonNull
    @Override
    public JobViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.job_item_with_delete, parent, false);
        return new JobViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull JobViewHolder holder, int position) {
        Job job = jobList.get(position);

        holder.titleTextView.setText(job.getTitle());
        holder.companyTextView.setText(job.getCompany());
        holder.applyLinkTextView.setText(job.getApplyLink());

        holder.deleteButton.setOnClickListener(v -> {
            String jobKey = jobKeys.get(position);

            // Delete the job from Firebase
            databaseReference.child(jobKey).removeValue()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(context, "Job deleted successfully!", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> Toast.makeText(context, "Failed to delete job", Toast.LENGTH_SHORT).show());
        });
    }

    @Override
    public int getItemCount() {
        return jobList.size();  // Return the correct number of items
    }

    static class JobViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, companyTextView, applyLinkTextView;
        Button deleteButton;

        public JobViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.job_title);
            companyTextView = itemView.findViewById(R.id.job_company);
            applyLinkTextView = itemView.findViewById(R.id.job_apply_link);
            deleteButton = itemView.findViewById(R.id.job_delete_button);
        }
    }
}
