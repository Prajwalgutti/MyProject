package com.community.connected;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class PlacementsDetailsActivity extends AppCompatActivity {

    private Button addButton;
    private Button viewButton;
    private Button deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_placements_details);

        addButton = findViewById(R.id.add_button);
        viewButton = findViewById(R.id.view_button);
        deleteButton = findViewById(R.id.delete_button);

        addButton.setOnClickListener(v -> {
            // Navigate to the Add Job activity
            Intent intent = new Intent(PlacementsDetailsActivity.this, AddJobActivity.class);
            startActivity(intent);
        });

        viewButton.setOnClickListener(v -> {
            // Navigate to the Placements view page
            Intent intent = new Intent(PlacementsDetailsActivity.this, PlacementsActivity.class);
            startActivity(intent);
        });

        deleteButton.setOnClickListener(v -> {
            // Navigate to the Placements delete page
            Intent intent = new Intent(PlacementsDetailsActivity.this, DeletePlacementsActivity.class);
            startActivity(intent);
        });
    }
}

