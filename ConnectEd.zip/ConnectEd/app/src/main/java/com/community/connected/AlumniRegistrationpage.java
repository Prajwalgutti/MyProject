package com.community.connected;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.textfield.TextInputEditText;
import android.widget.EditText;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AlumniRegistrationpage extends AppCompatActivity {

    private static final int REQUEST_CODE_POST_NOTIFICATIONS = 1;
    private TextInputEditText name, usn, branch, batch, email, password, profession;
    private EditText etUsername;

    private DatabaseReference database;
    private Button registerButton;
    private TextView timerText;
    private int remainingTime = 120000; // 2 minutes in milliseconds
    private static final String CHANNEL_ID = "alumni_requests_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alumni_registrationpage);

        // Initialize the TextInputEditText fields
        name = findViewById(R.id.name);
        usn = findViewById(R.id.usn);
        branch = findViewById(R.id.branch);
        batch = findViewById(R.id.batch);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        profession = findViewById(R.id.profession);
        etUsername = findViewById(R.id.username);
        registerButton = findViewById(R.id.register);

        database = FirebaseDatabase.getInstance().getReference("users");

        // Check if the permission is granted for Android 13 (API level 33) and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                // Request the permission if it's not granted
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_CODE_POST_NOTIFICATIONS);
            }
        }

        // Set the onClickListener for the register button
        registerButton.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            if (!username.isEmpty()) {
                // Create a unique key and store username
                String userId = database.push().getKey();
                if (userId != null) {
                    database.child(userId).setValue(username)
                            .addOnCompleteListener(task -> {
                                            // Do nothing after storing
                                        });
                            }
                        }
            showAdminApprovalDialog();
            sendNotificationToAdmin(); // Notify the admin
            new SendRegistrationDataTask().execute(); // Send the registration data in the background
        });
    }

    // Create a notification channel (required for Android 8.0+)
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Alumni Requests";
            String description = "Notifications for new alumni registration requests";
            int importance = android.app.NotificationManager.IMPORTANCE_HIGH;
            android.app.NotificationChannel channel = new android.app.NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            // Register the channel with the system
            android.app.NotificationManager notificationManager = getSystemService(android.app.NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    // Send a notification to the admin
    private void sendNotificationToAdmin() {
        // Check if the permission is granted before showing the notification
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            // Ensure notification channel is created before sending the notification
            createNotificationChannel();

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notification) // Replace with an icon in your res/drawable folder
                    .setContentTitle("New Alumni Request")
                    .setContentText("A new alumni registration request has been submitted.")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true); // Dismiss the notification when clicked

            // Get the NotificationManager
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

            // Ensure that notificationManager is not null and notify the user
            if (notificationManager != null) {
                notificationManager.notify(1, builder.build());
            } else {
                Log.e("NotificationError", "NotificationManager is null.");
            }
        } else {
            // If permission is not granted, request permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_CODE_POST_NOTIFICATIONS);
        }
    }

    private void showAdminApprovalDialog() {
        // Create the dialog for admin approval
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Admin Approval")
                .setMessage("Your request is being processed. Please wait for admin approval.")
                .setCancelable(false)
                .setPositiveButton("OK", (dialog, id) -> onApproval());

        // Show the dialog
        AlertDialog dialog = builder.create();
        dialog.show();

        // Set up the timer
        timerText = new TextView(this);
        timerText.setText( "Time remaining: 2:00");
        dialog.setView(timerText);

        // Start the countdown timer
        startCountDownTimer(dialog);
    }

    private void startCountDownTimer(final AlertDialog dialog) {
        new CountDownTimer(remainingTime, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000);
                int minutes = seconds / 60;
                seconds = seconds % 60;
                timerText.setText(String.format("Time remaining: %02d:%02d", minutes, seconds));
            }

            @Override
            public void onFinish() {
                timerText.setText("Time's up!");
                onApproval();
                dialog.dismiss();
            }
        }.start();
    }

    private void onApproval() {
        // Correct Intent creation
        Intent intent = new Intent(AlumniRegistrationpage.this, AlumniSignpage.class);
        startActivity(intent); // This is where the error occurred earlier
    }

    // AsyncTask to send the registration data to the request page
    private class SendRegistrationDataTask extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            // Simulate sending the data in the background
            sendRegistrationDataToRequestPage();
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            // You can show a message or perform any task after the data is sent
        }

        private void sendRegistrationDataToRequestPage() {
            // Get the registration data
            String alumniName = name.getText().toString();
            String alumniUsn = usn.getText().toString();
            String alumniBranch = branch.getText().toString();
            String alumniBatch = batch.getText().toString();
            String alumniEmail = email.getText().toString();
            String alumniPassword = password.getText().toString();
            String alumniProfession = profession.getText().toString();

            // Save data in SharedPreferences (or you can use a database or Firebase)
            SharedPreferences preferences = getSharedPreferences("AlumniRequests", MODE_PRIVATE); // Correct usage of SharedPreferences
            SharedPreferences.Editor editor = preferences.edit(); // Correct usage of editor
            editor.putString("name", alumniName); // Save the data
            editor.putString("usn", alumniUsn);
            editor.putString("branch", alumniBranch);
            editor.putString("batch", alumniBatch);
            editor.putString("email", alumniEmail);
            editor.putString("password", alumniPassword);
            editor.putString("profession", alumniProfession);
            editor.apply(); // Apply changes
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_POST_NOTIFICATIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Notification permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

