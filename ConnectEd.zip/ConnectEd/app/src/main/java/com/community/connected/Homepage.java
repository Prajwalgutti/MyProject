package com.community.connected;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Homepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        findViewById(R.id.gallery).setOnClickListener(view -> {
            Intent intent = new Intent(Homepage.this, ViewGallery.class);
            startActivity(intent);
        });

        findViewById(R.id.placement).setOnClickListener(view -> {
            Intent intent = new Intent(Homepage.this, PlacementsDetailsActivity.class);
            startActivity(intent);
        });

        findViewById(R.id.feedback).setOnClickListener(view -> {
            Intent intent = new Intent(Homepage.this, Feedback.class);
            startActivity(intent);
        });
    }
}