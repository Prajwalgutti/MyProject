package com.community.connected;

public class FeedbackItem {
    private String user;
    private String feedback;

    // Default constructor required for Firebase
    public FeedbackItem() {
    }

    // Constructor to create the FeedbackItem
    public FeedbackItem(String user, String feedback) {
        this.user = user;
        this.feedback = feedback;
    }

    // Getter and Setter methods
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
}
